from fastapi import APIRouter, HTTPException, Form, Depends, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
import sqlite3
import hashlib
import os
import smtplib
from email.mime.text import MIMEText
from pydantic import BaseModel
from datetime import datetime
from typing import Optional
from jose import JWTError, jwt

router = APIRouter(tags=["Onboarding"])

# --- CONFIG ---
GOVERNMENT_DB = "government.db"
SMTP_EMAIL = "rajeedandge444@gmail.com" 
SMTP_PASSWORD = "zkpm slsj txnh bclm"
SECRET_KEY = "super-secret-government-key" # Must match takeimage.py
ALGORITHM = "HS256"

# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["http://localhost:5173", "http://localhost:3000"],
#     allow_credentials=True,
#     allow_methods=["*"],
#     allow_headers=["*"],
# )

# --- HELPERS ---
def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()

def generate_session(email: str, name: str, role: str):
    token = hashlib.sha256(f"{email}{datetime.now()}".encode()).hexdigest()
    # ✅ Fix: Include the email in the session dictionary
    sessions[token] = {
        "email": email, 
        "name": name, 
        "admin_role": role
    }
    return token

def send_email(target, subject, body):
    from email.mime.multipart import MIMEMultipart
    msg = MIMEMultipart()
    msg['Subject'] = subject
    msg['From'] = SMTP_EMAIL
    msg['To'] = target
    msg.attach(MIMEText(body, 'plain'))
    try:
        server = smtplib.SMTP_SSL('smtp.gmail.com', 465, timeout=30)
        server.login(SMTP_EMAIL, SMTP_PASSWORD)
        server.send_message(msg)
        server.quit()
        return True
    except Exception as e:
        print(f"Nivaran Mail Engine Error: {e}")
        return False

# --- MODELS ---
class OnboardingUpdate(BaseModel):
    email: str
    step: int

# --- JWT SECURITY HELPER ---
def get_current_user(authorization: str = Form(None)):
    # Note: For PATCH/POST Form data, we sometimes get token from Header
    # This is a simplified version of the OAuth2 scheme
    if not authorization:
        raise HTTPException(status_code=401, detail="Missing Authorization Header")
    try:
        token = authorization.split(" ")[1]
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload.get("sub") # Returns the email
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid Security Handshake")

# --- APIS ---

@router.get("/api/onboarding/status")
async def get_onboarding_status(email: str):
    """
    SOVEREIGN STATE MACHINE: 
    Handles Resumption (Step 4 recovery) and Existence Checks.
    """
    email = email.lower().strip()
    conn = sqlite3.connect(GOVERNMENT_DB)
    conn.row_factory = sqlite3.Row 
    cursor = conn.cursor()
    
    try:
        # 1. Check if user exists in the system
        user = cursor.execute(
            "SELECT onboarding_step, is_onboarded, name FROM government_officers WHERE email = ?", 
            (email,)
        ).fetchone()

        # CASE A: User does not exist at all (Brand New)
        if not user:
            return {
                "step": 1, 
                "skip_otp": False, 
                "is_complete": False,
                "message": "New identity detected. Starting handshake."
            }

        # Convert row to dict for easy access
        user_data = dict(user)

        # CASE B: User is fully registered (The "Already Signed In" logic)
        if user_data["is_onboarded"] == 1:
            return {
                "step": 11, # Beyond onboarding
                "is_complete": True, 
                "skip_otp": False,
                "message": "Protocol Complete: You are already registered. Redirecting to Login...",
                "redirect": "/login"
            }

        # CASE C: User exists but hasn't finished (The "Resumption" logic)
        # If they stopped at Step 4, this returns Step 4 and tells frontend to skip OTP.
        return {
            "step": user_data["onboarding_step"],
            "skip_otp": True,
            "is_complete": False,
            "name": user_data["name"],
            "message": f"Welcome back! Resuming setup at Stage {user_data['onboarding_step']}."
        }

    except Exception as e:
        print(f"❌ Onboarding Status Error: {e}")
        return {"step": 1, "error": str(e)}
    finally:
        conn.close()

@router.patch("/api/onboarding/update-step")
async def update_onboarding_step(
    email: str = Form(...),
    step: int = Form(...),
    field: str = Form(None),
    value: str = Form(None)
):
    print(f"DEBUG: Syncing {field} for {email} at step {step}")

    conn = sqlite3.connect("government.db")
    cursor = conn.cursor()
    try:
        # 1. Check if user already has a progress record
        cursor.execute("SELECT step FROM onboarding_progress WHERE email = ?", (email,))
        existing_user = cursor.fetchone()

        if not existing_user:
            # If new, force start at Step 1 regardless of what frontend says
            cursor.execute(
                "INSERT INTO onboarding_progress (email, step) VALUES (?, 1)", 
                (email,)
            )
            actual_step = 1
        else:
            # For existing users, update to the new step provided by frontend
            actual_step = step
            cursor.execute(
                "UPDATE onboarding_progress SET step = ? WHERE email = ?", 
                (actual_step, email)
            )
        
        # 2. Update specific field if provided
        if field and value:
            allowed_columns = [
                "name", "email", "phone", "location", "uid_number", 
                "password_hash", "role", "admin_role", "admin_body", 
                "specific_role", "workspace_code", "is_setup", 
                "is_setup_complete", "onboarding_step", "is_onboarded"
            ]
            
            if field in allowed_columns:
                # Use parameterized query for the value, f-string for column (safe due to allowed_columns)
                cursor.execute(f"UPDATE onboarding_progress SET {field} = ? WHERE email = ?", (value, email))
            else:
                raise HTTPException(status_code=400, detail=f"Invalid field: {field}")

        conn.commit()
        return {"status": "success", "current_step": actual_step}

    except Exception as e:
        print(f"SQL Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        conn.close()

# @app.patch("/api/onboarding/update-step")
# async def update_onboarding_step(
#     email: str = Form(...),
#     step: int = Form(...),
#     field: Optional[str] = Form(None),
#     value: Optional[str] = Form(None)
# ):
#     """Persistent Onboarding Sync: Saves stage progress for resuming sessions."""
#     conn = sqlite3.connect(GOVT_DB)  # Officers live in government.db
#     email = email.lower()
    
#     # Check if user exists (partial record)
#     user = conn.execute("SELECT id FROM government_officers WHERE email = ?", (email,)).fetchone()
    
#     if not user:
#         # Create initial record if it doesn't exist during Stage 1
#         # We assume Name is sent in field/value if it's the first creation
#         if field == "name":
#             conn.execute("INSERT INTO government_officers (email, name, onboarding_step) VALUES (?, ?, ?)", (email, value, step))
#         else:
#             conn.close()
#             raise HTTPException(status_code=400, detail="Cannot initialize record without Name.")
#     else:
#         # Update existing record
#         query = f"UPDATE government_officers SET onboarding_step = ?"
#         params = [step]
#         if field and value:
#             query += f", {field} = ?"
#             params.append(value)
#         query += " WHERE email = ?"
#         params.append(email)
#         conn.execute(query, tuple(params))
        
#     conn.commit()
#     conn.close()
#     return {"status": "success", "step": step}

@router.get("/api/onboarding/check-code")
async def check_workspace_code(code: str, location: str):
    conn = sqlite3.connect(GOVERNMENT_DB)
    cursor = conn.cursor()
    try:
        # Check if this specific code exists for this specific location
        cursor.execute(
            "SELECT admin_body FROM workspaces WHERE workspace_code = ? AND location = ? AND is_active = 1", 
            (code, location)
        )
        result = cursor.fetchone()

        if result:
            return {"valid": True, "admin_body": result[0]}
        
        # Fallback for your development testing
        if code == "123456":
            return {"valid": True, "admin_body": "Test Department"}

        raise HTTPException(
            status_code=400, 
            detail=f"Invalid Security Key. Code {code} is not authorized for {location}."
        )
    finally:
        conn.close()

# @app.get("/api/onboarding/check-code")
# async def check_workspace_code(code: str, location: str):
#     """Hierarchy Crack: Validates Admin-generated workspace security keys."""
#     # REVOLUTIONARY DEVELOPER: In this simplified logic, we check if an Admin exists for this location with this code
#     conn = sqlite3.connect(GOVT_DB)  # Officers live in government.db
#     admin = conn.execute(
#         "SELECT name, email, specific_role FROM government_officers WHERE workspace_code = ? AND location = ? AND (admin_role = 'Admin' OR specific_role IN ('Sarpanch', 'Assistant Commissioner', 'Chief Officer'))", 
#         (code, location)
#     ).fetchone()
#     conn.close()
    
#     if not admin:
#         raise HTTPException(status_code=403, detail="INVALID SECURITY CODE: The entered key does not match any Lead Administrator in this jurisdiction.")
    
#     return {
#         "status": "valid", 
#         "admin_name": admin[0],
#         "admin_email": admin[1],
#         "admin_title": admin[2],
#         "message": "Workspace Handshake Successful. Admin Auth Confirmed."
#     }
@router.post("/api/v1/system/configure")
async def configure_system(
    full_name: str = Form(""),
    email: str = Form(""),
    phone: str = Form(""),
    uid: str = Form(""),
    password: str = Form(""),
    scope: str = Form(""),
    specific_role: str = Form(""),
    workspace_code: str = Form(""),
    admin_domain: Optional[str] = Form("None"),
    sla: int = Form(24),
    desks: int = Form(5),
    workers: int = Form(20),
    current_user: str = Depends(get_current_user) # Secure JWT Check
):
    """
    Step 10: The Sovereign Handshake.
    This anchors Identity (PII) and Governance Logic (Config) simultaneously.
    """
    target_email = current_user

    conn = sqlite3.connect(GOVT_DB)
    cursor = conn.cursor()

    try:
        # 1. Update the Individual Officer Profile (Identity Anchor)
        # We save the PII collected during the 9 stages
        new_hash = hash_password(password)
        cursor.execute('''
            UPDATE government_officers 
            SET phone = ?, uid_number = ?, password_hash = ?, 
                admin_body = ?, specific_role = ?, workspace_code = ?, 
                admin_domain = ?, is_setup_complete = 1, is_onboarded = 1, onboarding_step = 10
            WHERE email = ?
        ''', (phone, uid, new_hash, scope, specific_role, workspace_code, admin_domain, target_email))

        # 2. Update the Global System Configuration (Administrative Moulding)
        # This defines how the entire body functions (SLA, Workforce)
        cursor.execute("DELETE FROM system_config")
        cursor.execute('''
            INSERT INTO system_config (
                admin_email, admin_name, administrative_scope, sla_hours, 
                desk_officers, field_workers, category_mapping
            ) VALUES (?, ?, ?, ?, ?, ?, ?)''',
            (target_email, full_name, scope, sla, desks, workers, "{}")
        )

        conn.commit()
        return {"status": "success", "is_setup_complete": 1}

    except Exception as e:
        conn.rollback()
        print(f"Sovereign Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        conn.close()

@router.get("/api/v1/system/config")
async def get_system_config(current_user: str = Depends(get_current_user)):
    """Fetch for UI Moulding (Protected)"""
    conn = sqlite3.connect(GOVT_DB)
    conn.row_factory = sqlite3.Row
    config = conn.execute("SELECT * FROM system_config LIMIT 1").fetchone()
    conn.close()
    return dict(config) if config else {}

@router.post("/api/gov/finalize-onboarding")
async def finalize_gov_onboarding(
    email: str = Form(...),
    name: str = Form(...),
    phone: str = Form(...),
    location: str = Form(...),
    uid_number: str = Form(...),
    password: str = Form(...),
    admin_body: str = Form(...),
    specific_role: str = Form(...),
    workspace_code: str = Form(...),
    proof: UploadFile = File(None) # Optional if they didn't upload in final step
):
    conn = sqlite3.connect(GOVERNMENT_DB)
    cursor = conn.cursor()
    
    try:
        # 1. Handle File Upload (Identity Proof)
        proof_path = None
        if proof:
            os.makedirs("gov_proofs", exist_ok=True)
            file_ext = os.path.splitext(proof.filename)[1]
            proof_path = f"gov_proofs/{email}_final_proof{file_ext}"
            with open(proof_path, "wb") as f:
                f.write(await proof.read())

        # 2. Check if already exists in permanent table
        cursor.execute("SELECT id FROM government_officers WHERE email = ?", (email,))
        if cursor.fetchone():
            raise HTTPException(status_code=400, detail="This official is already registered.")

        # 3. Insert into permanent Government Officers table
        # Note: We use specific_role as the primary 'role' for the dashboard logic
        cursor.execute('''
            INSERT INTO government_officers (
                name, email, phone, location, uid_number, 
                proof_path, password_hash, role, admin_body, 
                specific_role, workspace_code, is_setup, is_setup_complete,is_onboarding, is_onboarded
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 1, 1, 1)
        ''', (
            name, email, phone, location, uid_number, 
            proof_path, hash_password(password), specific_role, 
            admin_body, specific_role, workspace_code
        ))

        # 4. Clean up the onboarding progress table
        cursor.execute("DELETE FROM onboarding_progress WHERE email = ?", (email,))

        conn.commit()
        
        # 5. Send Success Email
        send_email(
            email, 
            "Nivaran - Sovereign Account Initialized", 
            f"Hello {name}, your administrative account as {specific_role} has been successfully activated."
        )

        return {
            "status": "success",
            "message": "Account Anchored",
            "user": {
                "name": name,
                "email": email,
                "role": specific_role
            }
        }

    except sqlite3.IntegrityError as e:
        print(f"Integrity Error: {e}")
        raise HTTPException(status_code=400, detail="Database integrity error (possible duplicate UID or Email).")
    except Exception as e:
        conn.rollback()
        print(f"Finalization Failure: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        conn.close()

# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run(app, host="0.0.0.0", port=8004)