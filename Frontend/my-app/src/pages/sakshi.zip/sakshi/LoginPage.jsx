import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import axios from 'axios';
import { toast } from 'sonner';
import './AuthPage.css';

export default function LoginPage({ defaultRole }) {
  const navigate = useNavigate();
  const { login, error, setError } = useAuth();
  const { isDark, toggleTheme } = useTheme();

  const [step, setStep] = useState('credentials');
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [otp, setOtp] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [otpTimer, setOtpTimer] = useState(0);

  const signupPath = defaultRole === 'government' ? '/gov-signup' : '/citizen-signup';

  useEffect(() => {
    if (otpTimer > 0) {
      const interval = setInterval(() => setOtpTimer(t => t - 1), 1000);
      return () => clearInterval(interval);
    }
  }, [otpTimer]);

  const handleRequestOtp = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    try {
      await axios.post('http://localhost:8000/api/gov/send-otp', {
        email: email.trim(),
        name: name.trim(),
        role: defaultRole,
        is_signup: false
      });
      setStep('otp');
      setOtpTimer(60);
      toast.success("Handshake Initialized: Check your email");
    } catch (err) {
      setError(err.response?.data?.detail || "Authentication sequence failed");
    } finally {
      setSubmitting(false);
    }
  };

  const handleVerifyAndLogin = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await axios.post('http://localhost:8000/api/gov/verify-otp', { email, code: otp });
      if (res.data.status === 'success') {
        const setupDone = res.data.is_setup_complete === 1;
        login({
          email,
          role: res.data.role,
          is_onboarded: res.data.is_setup_complete === 1,
        }, res.data.token);

        toast.success("Identity Secured");
        navigate(res.data.role === 'government' ? (setupDone ? '/gov-landing' : '/admin-onboarding') : '/citizen');
      }
    } catch (err) {
      setError("Invalid Authorization Code");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="auth-page">
      {/* Interactive Theme Toggle */}
      <button className="auth-theme-toggle" onClick={toggleTheme}>
        {isDark ? '☀️' : '🌙'}
      </button>

      {/* Main Split Container */}
      <div className="auth-container-split">
        
        {/* Left Side: Sovereign Branding Text */}
        <motion.div 
          className="auth-text-side"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
        >
          <div className="brand-badge">GOVERNMENT SECURE ACCESS</div>
          <h1>Authenticate Your <span className="text-emerald-500">Sovereign Identity.</span></h1>
          <p>Access the unified command center for urban governance and grievance orchestration.</p>
          
          <div className="auth-features">
            <div className="feature-item">
              <div className="feature-icon">🛡️</div>
              <div>
                <strong>AES-GCM Encrypted</strong>
                <span>End-to-end data sovereignty</span>
              </div>
            </div>
            <div className="feature-item">
              <div className="feature-icon">⚡</div>
              <div>
                <strong>Zero-Trust Protocol</strong>
                <span>Multi-factor handshake initialization</span>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Right Side: Login Form */}
        <motion.div 
          className="auth-card"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
        >
          <div className="auth-header">
            <span className="auth-emblem">{defaultRole === 'government' ? '🏛️' : '👤'}</span>
            <h2>Sign In</h2>
            <p>Verification sequence required</p>
          </div>

          {error && <div className="auth-error-banner">{error}</div>}

          <AnimatePresence mode="wait">
            {step === 'credentials' ? (
              <motion.form 
                key="creds"
                className="auth-form" 
                onSubmit={handleRequestOtp}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
              >
                <div className="auth-field">
                  <label>Registered Name</label>
                  <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="Sakshi Chavan" required />
                </div>
                <div className="auth-field">
                  <label>Official Email</label>
                  <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="name@gov.in" required />
                </div>
                <button type="submit" className="btn-auth" disabled={submitting || otpTimer > 0}>
                  {submitting ? 'Initializing...' : 'REQUEST HANDSHAKE'}
                </button>
              </motion.form>
            ) : (
              <motion.form 
                key="otp"
                className="auth-form" 
                onSubmit={handleVerifyAndLogin}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <div className="otp-info">
                  <p>Code dispatched to <strong>{email}</strong></p>
                </div>
                <div className="auth-field">
                  <input
                    type="text"
                    value={otp}
                    onChange={e => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
                    placeholder="000000"
                    className="otp-input-large"
                    required
                  />
                </div>
                <button type="submit" className="btn-auth" disabled={submitting}>
                  VERIFY IDENTITY
                </button>
                <div className="otp-resend">
                  {otpTimer > 0 ? (
                    <span>Wait {otpTimer}s for new code</span>
                  ) : (
                    <button type="button" className="resend-link" onClick={handleRequestOtp}>Resend Handshake</button>
                  )}
                </div>
              </motion.form>
            )}
          </AnimatePresence>

          <div className='auth-toggle-footer'>
            New to the terminal? <button onClick={() => navigate(signupPath)}>Create Account</button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}