# --- 1. IMPORTING THE NECESSARY LIBRARY ---
# Importing the Roboflow SDK to communicate with the cloud-based AI model
from roboflow import Roboflow 
import os
from dotenv import load_dotenv
load_dotenv()
from cryptography.fernet import Fernet

# --- 2. CONFIGURATION & CLOUD CONNECTION ---
# Replace with your actual Private API Key from the Roboflow 'Deploy' tab
API_KEY = os.getenv("ROBOFLOW_API_KEY")

# Creating a connection object 'rf' to log into your Roboflow account
rf = Roboflow(api_key=API_KEY)

# Selecting your specific project from your workspace
# Based on your setup: "govt_ai_compliant"
ROBOFLOW_PROJECT = os.getenv("ROBOFLOW_PROJECT")
project = rf.workspace().project(ROBOFLOW_PROJECT)

# Loading the 'model' object from Version 1 of your project
ROBOFLOW_VERSION = int(os.getenv("ROBOFLOW_VERSION", 1))
model = project.version(ROBOFLOW_VERSION).model

# --- 3. THE AI SCANNING FUNCTION ---
# This function takes a local image path (e.g., 'uploads/image.jpg') and scans it
def run_ai_detection(image_path):
    # 'try' block ensures the app doesn't crash if internet fails
    try:
        # Sending image to Roboflow for 'Inference' (AI verification)
        # confidence=40 means ignore any results the AI isn't at least 40% sure about
        prediction = model.predict(image_path, confidence=40).json()
        
        # Extracting the list of found objects from the 'predictions' section of the response
        detections = prediction.get('predictions', [])
        print(prediction)
        # If the list size is greater than 0, a grievance (pothole) was found
        if len(detections) > 0:
            # Taking the result with the highest confidence (the first item)
            top_detect = detections[0]
            
            # Returning a package of data back to main.py
            return {
                "detected": True,                # AI confirms grievance is present
                "label": top_detect['class'],    # The name of the object (e.g., 'pothole')
                "confidence": top_detect['confidence'] # How sure the AI is (0.0 to 1.0)
            }
        
        # If the list is empty, the AI found no potholes
        else:
            return {
                "detected": False, 
                "label": "none", 
                "confidence": 0.0
            }
            
    # Handling potential errors (like API limits or network issues)
    except Exception as e:
        print(f"AI Detection Error: {e}")
        return {
            "detected": False, 
            "label": "error", 
            "confidence": 0.0
        }

ENCRYPTION_KEY = os.getenv("ENCRYPTION_KEY")
cipher_suite = Fernet(ENCRYPTION_KEY.encode()) if ENCRYPTION_KEY else None

def decrypt_data(data_hex: str) -> str:
    """Safe Decryption for the Officer Dashboards"""
    try:
        if not cipher_suite: return data_hex
        return cipher_suite.decrypt(data_hex.encode()).decode()
    except Exception:
        return data_hex # Fallback for unencrypted seed data