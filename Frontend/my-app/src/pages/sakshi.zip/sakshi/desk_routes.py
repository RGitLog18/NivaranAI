# desk_routes.py
from fastapi import APIRouter, Depends, HTTPException
import sqlite3
import os
from datetime import datetime, timedelta # 1. ADDED MISSING IMPORTS
from detective import decrypt_data 

router = APIRouter(prefix="/api/v1/desk", tags=["Desk Officer"])

DATABASE_PATH = "grievance.db"

@router.get("/dashboard-stats")
async def get_desk_stats(ward: str='General', domain: str='Roads'):
    try:
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        # 2. REVOLUTIONARY FIX: Use LIKE with wildcards
        # This allows "Roads" to match "Roads & Infrastructure"
        domain = domain.strip()
        search_term = f"%{domain}%"

        # Query 1: Total Load
        cursor.execute('''
            SELECT COUNT(*) FROM complaints 
            WHERE ward_zone=? AND ai_category LIKE ? AND status IN ('verified', 'assigned', 'resolved')
        ''', (ward, search_term))
        total_tasks = cursor.fetchone()[0]

        if total_tasks == 0:
            return {"total_today": 0, "urgent_count": "00", "sla_compliance": "100%"}

        # Query 2: Resolved on time
        cursor.execute('''
            SELECT COUNT(*) FROM complaints 
            WHERE ward_zone=? AND ai_category LIKE ? 
            AND status = 'resolved' 
            AND resolved_at <= deadline_at
        ''', (ward, search_term))
        on_time_resolved = cursor.fetchone()[0]

        # Query 3: Urgent count
        cursor.execute('''
            SELECT COUNT(*) FROM complaints 
            WHERE ward_zone=? AND ai_category LIKE ? AND ai_score >= 8.0 AND status != 'resolved'
        ''', (ward, search_term))
        urgent = cursor.fetchone()[0]

        compliance_rate = (on_time_resolved / total_tasks) * 100

        conn.close()
        return {
            "total_today": total_tasks,
            "urgent_count": f"{urgent:02d}",
            "sla_compliance": f"{int(compliance_rate)}%"
        }
    except Exception as e:
        print(f"SLA Calculation Error: {e}")
        return {"status": "error", "message": str(e)}
        
@router.get("/inbox")
async def get_desk_inbox(ward: str, domain: str):
    try:
        conn = sqlite3.connect(DATABASE_PATH)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        domain = domain.strip()
        search_term = f"%{domain}%"
        
        # Updated to LIKE
        cursor.execute('''
            SELECT id, location, ai_score, status, contractor_id, full_name 
            FROM complaints 
            WHERE ward_zone=? AND ai_category LIKE ? AND status != 'rejected'
            ORDER BY ai_score DESC
        ''', (ward, search_term))
        
        rows = cursor.fetchall()
        complaints = []
        for row in rows:
            d = dict(row)
            d["full_name"] = decrypt_data(d["full_name"])
            complaints.append(d)
            
        conn.close()
        return complaints
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/severity-trend")
async def get_severity_trend(ward: str, domain: str):
    try:
        with sqlite3.connect("grievance.db") as conn:
            cursor = conn.cursor()
            domain = domain.strip()
            search_term = f"%{domain}%"
            trend_data = []
            
            for i in range(6, -1, -1):
                # Calculate the date for the last 7 days
                target_date = (datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d')
                day_name = (datetime.now() - timedelta(days=i)).strftime('%a')
                
                # REVOLUTIONARY FIX: 
                # 1. Use AVG(ai_score) to show real severity trend.
                # 2. Use strftime to normalize the SQLite date comparison.
                cursor.execute('''
                    SELECT AVG(ai_score) FROM complaints 
                    WHERE ward_zone=? AND ai_category LIKE ? 
                    AND strftime('%Y-%m-%d', created_at) = ?
                ''', (ward, search_term, target_date))
                
                avg_val = cursor.fetchone()[0]
                # If no data for that day, return 0.0
                score = round(float(avg_val), 1) if avg_val else 0.0
                
                trend_data.append({"day": day_name, "val": score})
            
            return trend_data
    except Exception as e:
        print(f"Trend Calculation Error: {e}")
        return []

@router.get("/contractors")
async def get_contractors(ward: str=None, domain: str=None):
    # """REVOLUTIONARY: Real-time Load Balancing Audit."""
    print(f"📥 Received request for Ward: {ward}")
    
    try:
        target_ward = ward if (ward and ward != "undefined") else "Dombivli East"
        # target_domain = domain if domain and domain != "undefined" else "Roads"

        # 1. Connect to Government DB to get the team
        with sqlite3.connect("government.db") as gconn:
            gconn.row_factory = sqlite3.Row
            cursor_g = gconn.cursor()
            cursor_g.execute("""
                SELECT workspace_code FROM government_officers 
                WHERE location LIKE ? AND admin_role = 'Desk_Officer' 
                LIMIT 1
            """, (f"%{target_ward}%",))
            
            officer_row = cursor_g.fetchone()
            if not officer_row:
                print(f"⚠️ No Desk Officer found for ward: {target_ward}")
                return []
            
            target_workspace = officer_row['workspace_code'] if officer_row else "DOM-E-2026"

            # 2. Get all contractors who have that SAME workspace_code
            cursor_g.execute("""
                SELECT name,email,phone, specific_role  
                FROM government_officers 
                WHERE workspace_code = ? AND admin_role = 'Contractor'
            """, (target_workspace,))
            
            officers = [dict(row) for row in cursor_g.fetchall()]
        # 2. Connect to Grievance DB to calculate their active workload
        # with sqlite3.connect("grievance.db") as gr_conn:
        #     cursor_gr = gr_conn.cursor()
        #     for officer in officers:
        #         cursor_gr.execute("SELECT COUNT(*) FROM complaints WHERE contractor_id = ? AND status = 'assigned'", (officer['name'],))
        #         load = cursor_gr.fetchone()[0]
                
        #         # DERIVE STATUS NON-VERBALLY
        #         officer['current_load'] = load
        #         officer['availability'] = "Available" if load == 0 else "Active" if load < 3 else "Overloaded"
        #         officer['color'] = "#10B981" if load == 0 else "#F59E0B" if load < 3 else "#EF4444"

        return officers
    except Exception as e:
        return {"status": "error", "message": str(e)}

@router.get("/contractor-portfolio/{name}")
async def get_contractor_portfolio(name: str):
    """REVOLUTIONARY: Automated Performance Audit for a specific contractor."""
    try:
        # 1. Connect to Grievance DB to see their work history
        with sqlite3.connect("grievance.db") as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Fetch all resolved tasks by this contractor
            cursor.execute('''
                SELECT id, location, ai_score, image_path, resolution_image_path, 
                       created_at, resolved_at 
                FROM complaints 
                WHERE contractor_id = ? AND status = 'resolved'
            ''', (name,))
            history = [dict(row) for row in cursor.fetchall()]

        # 2. Calculate Real-time Metrics
        total_resolved = len(history)
        
        # Calculate Efficiency (Demo logic: if we have 5 resolved items, efficiency is high)
        efficiency = "98%" if total_resolved > 5 else "85%" if total_resolved > 0 else "N/A"
        
        return {
            "name": name,
            "total_resolved": total_resolved,
            "efficiency_score": efficiency,
            "work_history": history # This contains the Before/After photo links
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))