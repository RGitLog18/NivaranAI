from fastapi import FastAPI, File, Form, UploadFile, BackgroundTasks, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel
import sqlite3
import uvicorn
import time
import os
import random
from datetime import datetime, timedelta
from typing import Optional, List
from jose import JWTError, jwt
from passlib.context import CryptContext
from cryptography.fernet import Fernet
from dotenv import load_dotenv

from detective import run_ai_detection  # AI Verification (Roboflow)
from priortize import prioritize_complaint  # Categorization & Logic
from Clustering import get_clusters  # Clustering Logic
from verification import (
    auth_context, OTPRequest, VerifyRequest, CitizenFinal, 
    init_verification_db, send_email, hash_password
)
from desk_routes import router as desk_router
import status_update
import reglogverify
import onboarding
import hashlib
from email.mime.text import MIMEText

# Load environment variables
load_dotenv()

app = FastAPI(title="Nivaran Backend - Enterprise Verified AI Pipeline")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173", 
        "http://127.0.0.1:5173",
        "http://localhost:3000"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app = FastAPI(title="Nivaran Backend - Enterprise Verified AI Pipeline")
app.include_router(status_update.router)
# app.include_router(verification.router)
# app.include_router(priority.router)
# app.include_router(Clustering.router)
app.include_router(reglogverify.router)
app.include_router(onboarding.router)
app.include_router(desk_router)

auth_context = {}
sessions = {} # {token: {"name": str, "role": str}}

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- 2. SECURITY CONFIGURATION ---
DATABASE_PATH = os.getenv("DATABASE_PATH", "grievance.db")   # Complaints & core data
CITIZEN_DB = os.getenv("CITIZEN_DB_PATH", "citizen.db")          # Citizens, auth, system_config
GOVERNMENT_DB = os.getenv("GOVERNMENT_DB_PATH", "government.db")  # Government officers, auth, system_config
GRIEVANCE_DB = os.getenv("GRIEVANCE_DB_PATH", "grievance.db")    # Complaints, AI results, status
SECRET_KEY = os.getenv("JWT_SECRET", "super-secret-government-key")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30
UPLOAD_DIR = os.getenv("UPLOAD_DIR", "uploads")
SMTP_EMAIL = "rajeedandge444@gmail.com" 
SMTP_PASSWORD = "zkpm slsj txnh bclm"

# AES-256-GCM Implementation (Sovereign Hardening)
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
ENCRYPTION_KEY_RAW_STR = os.getenv("ENCRYPTION_KEY", "32-bytes-of-sovereign-intelligence-key!")
# Ensure 32 bytes for AES-256
key_bytes = ENCRYPTION_KEY_RAW_STR.encode().ljust(32)[0:32]
aesgcm = AESGCM(key_bytes)

# Password Hashing Setup
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")

app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")

# In-memory OTP store
auth_context = {}

# --- MODELS ---
class OTPRequest(BaseModel):
    email: str
    name: str
    role: str
    is_signup: bool

class VerifyRequest(BaseModel):
    email: str
    code: str

class CitizenRegister(BaseModel):
    name: str
    email: str
    phone: str
    uid_number: str
    password: str

#--- Definitions ----
def get_db_connection(db_name):
    conn = sqlite3.connect(db_name)
    conn.row_factory = sqlite3.Row
    return conn

# --- EMAIL HELPER ---
def send_email(target, subject, body):
    msg = MIMEText(body)
    msg['Subject'] = subject
    msg['From'] = SMTP_EMAIL
    msg['To'] = target
    try:
        server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
        server.login(SMTP_EMAIL, SMTP_PASSWORD)
        server.sendmail(SMTP_EMAIL, [target], msg.as_string())
        server.quit()
        return True
    except Exception as e:
        print(f"Email Error: {e}")
        return False

def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()

def generate_session(email: str, name: str, role: str):
    token = hashlib.sha256(f"{email}{datetime.now()}".encode()).hexdigest()
    sessions[token] = {"name": name, "role": role}
    return token


def encrypt_data(data: str) -> str:
    """Industrial-Grade AES-256-GCM Encryption"""
    nonce = os.urandom(12)
    ciphertext = aesgcm.encrypt(nonce, data.encode(), None)
    return (nonce.hex() + ciphertext.hex())

def decrypt_data(data_hex: str) -> str:
    """Industrial-Grade AES-256-GCM Decryption"""
    data_bytes = bytes.fromhex(data_hex)
    nonce = data_bytes[0:12]
    ciphertext = data_bytes[12:len(data_bytes)]
    return aesgcm.decrypt(nonce, ciphertext, None).decode()

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

async def get_current_user(token: str = Depends(oauth2_scheme)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
        return username
    except JWTError:
        raise credentials_exception

async def check_admin_authority(current_user: str = Depends(get_current_user)):
    """Strict Backend Provision: Admin Gatekeeping."""
    conn = sqlite3.connect(CITIZEN_DB)
    cursor = conn.cursor()
    # Teammate logic uses 'role' or a specific flag
    cursor.execute("SELECT role FROM government_officers WHERE email = ?", (current_user,))
    user = cursor.fetchone()
    conn.close()
    
    if not user or user[0].lower() not in ['government', 'admin']:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="GOVERNMENT AUTHORITY REQUIRED: Access restricted to Government staff."
        )
    return current_user

def init_db():
    # --- MIGRATION: Add admin columns if schema is older ---
    for col, defn in [("admin_email", "TEXT"), ("admin_name", "TEXT")]:
        try:
            gcursor.execute(f"ALTER TABLE system_config ADD COLUMN {col} {defn}")
        except Exception:
            pass

    gconn = sqlite3.connect(GOVERNMENT_DB)
    gcursor = gconn.cursor()
    # Persistent Auth Context: Thread-Safe SQLite Storage for OTPs
    gcursor.execute('''
        CREATE TABLE IF NOT EXISTS auth_otps (
            email TEXT PRIMARY KEY,
            code TEXT,
            expiry TEXT,
            sent_at TEXT,
            verified INTEGER DEFAULT 0,
            role TEXT
        )
    ''')

    # Performance Crack: Authentication Indexing for sub-50ms query speed
    gcursor.execute('CREATE INDEX IF NOT EXISTS idx_citizens_email ON citizens(email)')
    gcursor.execute('CREATE INDEX IF NOT EXISTS idx_government_officers_email ON government_officers(email)')
    gcursor.execute("PRAGMA journal_mode=WAL")
    gconn.commit()
    gconn.close()

init_db()
# --- AUTH APIS (Signup & Login) ---

@app.post("/api/citizen/send-otp")
async def citizen_send_otp(data: OTPRequest):
    email = data.email.strip().lower()
    is_signup = data.is_signup

    # Database: citizen.db | Table: citizens
    with sqlite3.connect(CITIZEN_DB) as conn:
        cursor = conn.cursor()
        # For citizens, we check if the email exists
        user = cursor.execute(
            "SELECT email FROM citizens WHERE email = ?", 
            (email,)
        ).fetchone()

    # LOGIN CHECK: Citizen must have an account
    if not is_signup and not user:
        raise HTTPException(status_code=404, detail="Citizen account not found. Please sign up.")

    # SIGNUP CHECK: Prevent duplicate citizen accounts
    if is_signup and user:
        raise HTTPException(status_code=400, detail="Citizen email already registered. Please login.")

    # Generate OTP and store in shared auth_context
    otp_code = str(random.randint(100000, 999999))
    auth_context[email] = {
        "code": otp_code,
        "expiry": datetime.now() + timedelta(minutes=10),
        "verified": False,
        "role": "citizen",
        "name": data.name,
        "is_signup": is_signup
    }

    print(f"👤 CITIZEN OTP for {email}: {otp_code}")
    send_email(email, "Citizen Portal Verification", f"Your Nivaran verification code is: {otp_code}")
    
    return {"status": "success", "message": "OTP sent successfully."}

@app.post("/api/citizen/verify-otp")
async def citizen_verify_otp(data: VerifyRequest):
    email = data.email.strip().lower()
    record = auth_context.get(email)

    if not record:
        raise HTTPException(status_code=404, detail="OTP session expired or not found")

    if record["code"] != data.code:
        raise HTTPException(status_code=400, detail="Invalid Handshake Code.")

    # Mark as verified in memory
    record["verified"] = True
    is_signup = record.get("is_signup", False)

    # --- CASE 1: LOGIN FLOW ---
    if not is_signup:
        # Database: citizen.db | Table: citizens
        with sqlite3.connect(CITIZEN_DB) as conn:
            conn.row_factory = sqlite3.Row
            user = conn.execute(
                "SELECT * FROM citizens WHERE email = ?", 
                (email,)
            ).fetchone()

        if not user:
            raise HTTPException(status_code=404, detail="Citizen records missing. Please sign up.")
        
        user_dict = dict(user)
        token = generate_session(user_dict["email"], user_dict["name"], "citizen")

        # Citizens always go to the main citizen dashboard
        return {
            "status": "success",
            "token": token,
            "user": {
                "name": user_dict["name"],
                "email": user_dict["email"],
                "phone": user_dict["phone"],
                "role": "citizen",
                "is_setup_complete": 1
            },
            "redirect_to": "/citizen"
        }

    # --- CASE 2: SIGNUP FLOW ---
    token = generate_session(email, record.get("name", "New Citizen"), "citizen")
    return {
        "status": "success", 
        "token": token,
        "message": "Citizen Identity Verified. Complete your profile."
    }

@app.post("/api/citizen/register")
async def register_citizen(data: CitizenFinal):
    if not auth_context.get(data.email, {}).get("verified"):
        raise HTTPException(status_code=403, detail="Please verify your email first.")
    
    conn = sqlite3.connect(CITIZEN_DB)
    try:
        conn.execute("INSERT INTO citizens (name, email, phone, uid_number, password_hash) VALUES (?, ?, ?, ?, ?)",
            (data.name, data.email, data.phone, data.uid_number, hash_password(data.password)))
        conn.commit()
        
        token = generate_session(data.email, data.name, "citizen")
        if data.email in auth_context: del auth_context[data.email]
        
        return {"status": "success", "token": token, "redirect_to": "/citizen"}
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=400, detail="User already exists.")
    finally: conn.close()

# --- COMPLAINT SUBMISSION PIPELINE ---

async def run_ai_pipeline(complaint_id, file_path, description, lat, lon, location_text):
    """Background Task: YOLOv11 Scan + NLP Prioritization."""
    try:
        # 1. Image Verification (YOLOv11)
        ai_result = run_ai_detection(file_path)
        
        # 2. Triage & Priority (NLP + Geospatial)
        logic = prioritize_complaint(description, ai_result, lat, lon, location_text)
        
        # 3. Update Status
        status = "verified" if ai_result['detected'] else "rejected"
        
        conn = sqlite3.connect(GRIEVANCE_DB)
        conn.execute('''
            UPDATE complaints 
            SET status=?, priority=?, ai_category=?, ai_score=? 
            WHERE id=?
        ''', (status, logic['priority'], logic['category'], logic['score'], complaint_id))
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"AI Pipeline Error: {e}")

@app.post("/api/citizen/submit-complaint")
async def submit_complaint(
    background_tasks: BackgroundTasks,
    full_name: str = Form(...),
    phone_number: str = Form(...),
    email: str = Form(...), # Added for OTP verification
    language: str = Form(...),
    description: str = Form(...),
    location: str = Form(...),
    latitude: float = Form(0.0),
    longitude: float = Form(0.0),
    ward_zone: str = Form(...),
    file: UploadFile = File(...)
):
    """
    Revolutionary Developer Entry Point:
    Validates OTP verification status before triggering AI scan.
    """
    # --- FAIL-FAST DUPLICATE DETECTION (10m Radius) ---
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    # Using a simple bounding box for 10m approximately (0.0001 degrees)
    cursor.execute("""
        SELECT id FROM complaints 
        WHERE status IN ('pending', 'verified', 'assigned') 
        AND ABS(latitude - ?) < 0.0001 
        AND ABS(longitude - ?) < 0.0001
        LIMIT 1
    """, (latitude, longitude))
    duplicate = cursor.fetchone()
    if duplicate:
        conn.close()
        raise HTTPException(
            status_code=400,
            detail="Hotspot Detected: Our team is already on-site at this location (Case ID: " + str(duplicate[0]) + ")."
        )
    conn.close()

    # STRICT Conflict Resolution: Verify OTP Identity Layer first
    email = email.lower()
    verification_record = auth_context.get(email)
    if not verification_record or not verification_record.get("verified"):
        raise HTTPException(status_code=403, detail="STRICT ORDER: Citizen must verify OTP before filing a grievance.")

    complaint_id = None
    try:
        # STEP 1: SAVE IMAGE (Maintain performance with await file.read())
        os.makedirs("uploads", exist_ok=True)
        file_loc = f"uploads/{file.filename}"
        content = await file.read()
        with open(file_loc, "wb+") as file_obj:
            file_obj.write(content)
        
        # STEP 2: CREATE PENDING RECORD (Immediate Handshake)
        encrypted_name = encrypt_data(full_name)
        encrypted_phone = encrypt_data(phone_number)
        
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO complaints (
                full_name, phone_number, language,
                description, location, latitude, longitude, ward_zone, image_path, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
            (
                encrypted_name, encrypted_phone, language,
                description, location, latitude, longitude, ward_zone, file_loc, 'pending'
            )
        )
        complaint_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        # --- YOLOv11 + NLP MULTIMODAL GUARD (FIRE-AND-FORGET) ---
        background_tasks.add_task(
            run_task_back,
            complaint_id, file_loc, description, location, latitude, longitude
        )
        
        # Cleanup verification context after successful submission
        del auth_context[email]
        
        # STEP 4: SUCCESS RESPONSE (Immediate feedback to citizen)
        return {
            "status": "success",
            "id": complaint_id,
            "message": "Verified! Complaint received. AI Triaging is starting in the background."
        }
    except Exception as e:
        print(f"Server Error: {e}")
        return {"status": "error", "message": str(e)}

if __name__ == "__main__":
    import uvicorn
    # Init DBs
    c_conn = sqlite3.connect(CITIZEN_DB)
    c_conn.execute('CREATE TABLE IF NOT EXISTS citizens (id INTEGER PRIMARY KEY, name TEXT, email TEXT UNIQUE, phone TEXT, uid_number TEXT, password_hash TEXT)')
    c_conn.close()
    
    g_conn = sqlite3.connect(GRIEVANCE_DB)
    g_conn.execute('CREATE TABLE IF NOT EXISTS complaints (id INTEGER PRIMARY KEY, full_name TEXT, phone_number TEXT, email TEXT, language TEXT, text_desc TEXT, location TEXT, ward_zone TEXT, latitude REAL, longitude REAL, image_path TEXT, status TEXT, priority TEXT, ai_category TEXT, ai_score REAL)')
    g_conn.close()
    
    uvicorn.run(app, host="0.0.0.0", port=8000)